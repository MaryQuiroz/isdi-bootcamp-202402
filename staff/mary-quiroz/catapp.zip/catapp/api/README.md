# API
## endpoints
 User
- register user
- login user
- logout
- delete account
Cat
- add cat
- get cat
- get all cats
- update
- delete cat

Task
- add task
- get task
- get all task
- update task
- delete task

Remider

- add reminder
- get reminder
- get all reminder
- update reminder
- delete reminder

