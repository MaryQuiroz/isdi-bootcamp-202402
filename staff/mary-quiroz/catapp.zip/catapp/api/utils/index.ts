import tracer from 'tracer'
import colors from 'colors'


const logger = tracer.colorConsole({
    filters: {
        debug: colors.green,
        info: colors.blue,
        warn: colors.yellow,
        error: colors.red
    }
})

export {
    logger
}