import React, { createContext, useState } from 'react';

export const AppContext = createContext();
